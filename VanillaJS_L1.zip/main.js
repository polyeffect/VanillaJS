let score = 0;
let scoreText = document.getElementById('score');
let coinBtn = document.querySelector('#btn');

let level = 1;
let levelText = document.getElementById('lv-txt');
let levelUpBtn = document.getElementById('lv-btn');

// Image Sequence
let imgNum = 0;
let img = new Image();
let canvas = document.getElementById('sequence');
let ctx = canvas.getContext('2d');

function addScore() {
    score += 100 * level; // score = score + 100 * level
    scoreText.innerText = "Score: " + score;
}

setInterval(addScore, 1000);
coinBtn.addEventListener('click', addScore);

// Level Up
levelUpBtn.addEventListener('click', levelUp);

function levelUp() {
    if (score > (1000 * level)) {
        score -= 1000 * level;
        scoreText.innerText = "Score: " + score;

        level++;
        levelText.innerText = "LV: " + level;
    }
}

// Function Expression
// Image Sequence
playSequence();

img.src = "images/sequence/Coin_Sequence0.png";

function playSequence() {
    let timer = setInterval(function() {
        if (imgNum > 13) {
            imgNum = 0;
        }

        player(imgNum);
        imgNum++;
    }, 100);
}

function player(num) {
    img.src = "images/sequence/Coin_Sequence" + num + ".png";
}

img.addEventListener('load', function() {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.drawImage(img, 0, 0);
});